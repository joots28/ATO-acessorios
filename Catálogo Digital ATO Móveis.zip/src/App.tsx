import { useEffect, useMemo, useState } from "react";
import { categories, products, wa, type Product } from "./data";

type Route = { page: "home" } | { page: "catalog"; cat?: string; q?: string };

function parseHash(): Route {
  const h = location.hash.replace(/^#/, "");
  if (h.startsWith("/catalogo")) {
    const sp = new URLSearchParams(h.split("?")[1] || "");
    return { page: "catalog", cat: sp.get("cat") || undefined, q: sp.get("q") || undefined };
  }
  return { page: "home" };
}

const Arrow = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
);
const WaIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.2 14.1c-.2.6-1.300 1.200-1.800 1.200-.5.100-1 .2-3.300-.7-2.800-1.100-4.600-4-4.700-4.200-.1-.2-1.100-1.500-1.100-2.800s.7-2 1-2.300c.2-.3.5-.3.700-.3h.5c.2 0 .4 0 .6.500l.8 2c.1.200.1.400 0 .5l-.4.600-.3.400c-.1.200-.3.300-.1.600.2.300.8 1.300 1.700 2.100 1.200 1 2.100 1.300 2.400 1.500.3.100.5.100.6-.1l.9-1.100c.2-.3.400-.2.600-.1l1.900.9c.3.100.5.200.5.300.100.100.100.600-.1 1.200Z" /></svg>
);

function ProductArt({ cat, className = "" }: { cat: string; className?: string }) {
  const idx = categories.findIndex((c) => c.id === cat);
  const hue = 135 + (idx % 5) * 6;
  return (
    <div className={`relative overflow-hidden bg-gradient-to-br from-ato-50 to-ato-200 ${className}`} style={{ filter: `hue-rotate(${hue - 140}deg)` }}>
      <svg viewBox="0 0 200 150" className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id={`m${idx}`} x1="0" x2="1" y1="0" y2="1"><stop offset="0" stopColor="#f5f7f6" /><stop offset="1" stopColor="#9aa3a0" /></linearGradient>
        </defs>
        <ellipse cx="100" cy="128" rx="62" ry="7" fill="#123a24" opacity=".12" />
        {idx % 3 === 0 && <><rect x="52" y="52" width="96" height="14" rx="7" fill={`url(#m${idx})`} stroke="#6b7370" /><circle cx="62" cy="59" r="3" fill="#6b7370" /><circle cx="138" cy="59" r="3" fill="#6b7370" /><rect x="52" y="76" width="96" height="14" rx="7" fill={`url(#m${idx})`} stroke="#6b7370" opacity=".7" /></>}
        {idx % 3 === 1 && <><circle cx="100" cy="72" r="34" fill={`url(#m${idx})`} stroke="#6b7370" /><circle cx="100" cy="72" r="20" fill="#e8ecea" stroke="#6b7370" /><circle cx="100" cy="72" r="6" fill="#6b7370" /></>}
        {idx % 3 === 2 && <><path d="M54 100 L54 50 L146 50" stroke="#6b7370" strokeWidth="12" fill="none" strokeLinecap="round" strokeLinejoin="round" /><path d="M54 100 L54 50 L146 50" stroke="#dfe4e2" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round" /></>}
      </svg>
      <span className="absolute left-3 top-2 font-display text-xs font-semibold tracking-widest text-ato-700/70">{String(idx + 1).padStart(2, "0")}</span>
    </div>
  );
}

function Header({ route }: { route: Route }) {
  const [open, setOpen] = useState(false);
  const links = [
    ["#/", "Início"], ["#/catalogo", "Catálogo"], ["#/#sobre", "A ATO"], ["#/#contato", "Contato"],
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-black/5 bg-white/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 lg:h-20">
        <a href="#/" className="flex items-center gap-3"><img src="/logo.jpg" alt="ATO Acessórios para Móveis" className="h-12 w-12 object-contain lg:h-16 lg:w-16" /></a>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map(([h, l]) => (
            <a key={h} href={h} onClick={() => h.includes("#/#") && scrollTo(h.slice(3))} className={`font-display text-lg font-semibold uppercase tracking-wide transition hover:text-ato-700 ${(l === "Catálogo" && route.page === "catalog") || (l === "Início" && route.page === "home") ? "text-ato-700" : "text-graphite"}`}>{l}</a>
          ))}
          <a href={wa("Olá! Gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-ato-700 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-ato-900"><WaIcon /> Orçamento</a>
        </nav>
        <button aria-label="Menu" className="md:hidden" onClick={() => setOpen(!open)}>
          <svg width="26" height="26" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"><path d={open ? "M6 6l12 12M18 6L6 18" : "M4 7h16M4 12h16M4 17h16"} /></svg>
        </button>
      </div>
      {open && (
        <div className="border-t border-black/5 bg-white px-5 pb-5 md:hidden">
          {links.map(([h, l]) => (
            <a key={h} href={h} onClick={() => { setOpen(false); h.includes("#/#") && scrollTo(h.slice(3)); }} className="block py-3 font-display text-xl font-semibold uppercase text-graphite">{l}</a>
          ))}
          <a href={wa("Olá! Gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer" className="mt-2 flex items-center justify-center gap-2 rounded-full bg-ato-700 px-5 py-3 font-semibold text-white"><WaIcon /> Solicitar orçamento</a>
        </div>
      )}
    </header>
  );
}

function scrollTo(id: string) {
  setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }), 60);
}

function Card({ p, onOpen }: { p: Product; onOpen: (p: Product) => void }) {
  const cat = categories.find((c) => c.id === p.cat)!;
  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-black/10 bg-white transition hover:-translate-y-1 hover:shadow-xl">
      <button onClick={() => onOpen(p)} className="text-left">
        <ProductArt cat={p.cat} className="aspect-[4/3]" />
        <div className="p-5 pb-3">
          <p className="text-xs font-semibold uppercase tracking-wider text-ato-700">{cat.short}</p>
          <h3 className="mt-1 min-h-[3rem] text-lg font-semibold leading-snug text-graphite">{p.name}</h3>
          <p className="mt-2 text-sm text-black/50">{p.material} · {p.finish}</p>
        </div>
      </button>
      <div className="mt-auto flex items-center justify-between gap-2 px-5 pb-5">
        <button onClick={() => onOpen(p)} className="text-sm font-semibold text-ato-700 hover:underline">Ver detalhes</button>
        <a href={wa(`Olá! Gostaria de orçamento do produto: ${p.name} (cód. ${p.code}).`)} target="_blank" rel="noreferrer" aria-label="Orçar pelo WhatsApp" className="inline-flex items-center gap-1.5 rounded-full bg-ato-50 px-3.5 py-2 text-sm font-semibold text-ato-900 transition hover:bg-ato-700 hover:text-white"><WaIcon /> Orçar</a>
      </div>
    </article>
  );
}

function Modal({ p, onClose }: { p: Product | null; onClose: () => void }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    addEventListener("keydown", k);
    return () => removeEventListener("keydown", k);
  }, [onClose]);
  if (!p) return null;
  const cat = categories.find((c) => c.id === p.cat)!;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 sm:items-center sm:p-6" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="max-h-[92vh] w-full max-w-4xl overflow-auto rounded-t-3xl bg-white sm:rounded-3xl md:grid md:grid-cols-2">
        <ProductArt cat={p.cat} className="aspect-[4/3] md:aspect-auto md:min-h-[420px]" />
        <div className="p-6 sm:p-8">
          <div className="flex items-start justify-between gap-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-ato-700">{cat.name}</p>
            <button onClick={onClose} aria-label="Fechar" className="-mt-1 rounded-full p-1 hover:bg-black/5"><svg width="22" height="22" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg></button>
          </div>
          <h2 className="mt-2 font-display text-3xl font-bold leading-tight text-graphite">{p.name}</h2>
          <p className="mt-1 text-sm text-black/50">Código {p.code}</p>
          <dl className="mt-6 divide-y divide-black/10 border-y border-black/10 text-sm">
            {([["Material", p.material], ["Acabamento", p.finish], ...p.specs] as [string, string][]).map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 py-2.5"><dt className="text-black/50">{k}</dt><dd className="text-right font-medium text-graphite">{v}</dd></div>
            ))}
          </dl>
          <a href={wa(`Olá! Gostaria de orçamento do produto: ${p.name} (cód. ${p.code}).`)} target="_blank" rel="noreferrer" className="mt-6 flex items-center justify-center gap-2 rounded-full bg-ato-700 px-6 py-3.5 font-semibold text-white transition hover:bg-ato-900"><WaIcon /> Solicitar orçamento no WhatsApp</a>
          <p className="mt-3 text-center text-xs text-black/40">Imagem ilustrativa. Fotos oficiais em breve.</p>
        </div>
      </div>
    </div>
  );
}

function Home({ open }: { open: (p: Product) => void }) {
  const featured = products.filter((p) => p.featured);
  return (
    <>
      <section className="relative overflow-hidden bg-ato-900 text-white">
        <div className="pointer-events-none absolute -right-40 -top-40 h-[620px] w-[900px] rotate-[-14deg] rounded-[50%] border-[36px] border-ato-500/20" />
        <div className="pointer-events-none absolute -right-20 top-10 h-[560px] w-[820px] rotate-[-14deg] rounded-[50%] border-[18px] border-ato-500/25" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-5 py-20 lg:grid-cols-[1.3fr_1fr] lg:py-32">
          <div>
            <p className="font-display text-lg font-semibold uppercase tracking-[0.25em] text-ato-200">Acessórios para móveis</p>
            <h1 className="mt-4 font-display text-5xl font-bold uppercase leading-[0.95] sm:text-7xl">Tudo o que o seu móvel precisa, em um só fornecedor.</h1>
            <p className="mt-6 max-w-xl text-lg text-white/75">Mais de 3.400 itens em 15 categorias para marceneiros, fabricantes de móveis e lojas. Qualidade, variedade e atendimento direto.</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="#/catalogo" className="inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 font-semibold text-ato-900 transition hover:bg-ato-200">Ver catálogo <Arrow /></a>
              <a href={wa("Olá! Gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-white/40 px-7 py-3.5 font-semibold transition hover:bg-white/10"><WaIcon /> Pedir orçamento</a>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 self-end">
            {[["3.420+", "itens no catálogo"], ["15", "categorias"], ["B2B", "atendimento ao setor"], ["100%", "foco em moveleiro"]].map(([n, l]) => (
              <div key={l} className="rounded-2xl border border-white/15 bg-white/5 p-5 backdrop-blur"><div className="font-display text-4xl font-bold">{n}</div><div className="text-sm text-white/65">{l}</div></div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div><p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-ato-700">Catálogo</p><h2 className="font-display text-4xl font-bold uppercase text-graphite sm:text-5xl">15 categorias principais</h2></div>
          <a href="#/catalogo" className="inline-flex items-center gap-2 font-semibold text-ato-700 hover:underline">Catálogo completo <Arrow /></a>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c, i) => (
            <a key={c.id} href={`#/catalogo?cat=${c.id}`} className="group relative flex gap-4 overflow-hidden rounded-2xl border border-black/10 p-3 transition hover:border-ato-700 hover:shadow-lg">
              <ProductArt cat={c.id} className="h-24 w-28 shrink-0 rounded-xl" />
              <div className="min-w-0 py-1">
                <span className="font-display text-sm font-semibold text-ato-500">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="font-semibold leading-tight text-graphite">{c.short}</h3>
                <p className="mt-1 line-clamp-2 text-sm text-black/55">{c.desc}</p>
              </div>
            </a>
          ))}
        </div>
      </section>

      <section className="bg-ato-50 py-20">
        <div className="mx-auto max-w-7xl px-5">
          <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-ato-700">Mais procurados</p>
          <h2 className="font-display text-4xl font-bold uppercase text-graphite sm:text-5xl">Produtos em destaque</h2>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((p) => <Card key={p.id} p={p} onOpen={open} />)}
          </div>
        </div>
      </section>

      <section id="sobre" className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-2">
        <div>
          <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-ato-700">A ATO</p>
          <h2 className="font-display text-4xl font-bold uppercase text-graphite sm:text-5xl">Parceira de quem faz móveis</h2>
          <p className="mt-5 text-lg text-black/65">A ATO — Acessórios para Móveis reúne ferragens e componentes para atender o setor moveleiro com variedade, procedência e agilidade. Do pequeno marceneiro à indústria, ajudamos a encontrar o item certo para cada projeto.</p>
          <p className="mt-4 text-sm text-black/40">Texto institucional provisório, a ser substituído pelo conteúdo oficial.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {[["Variedade", "Milhares de itens em um único catálogo."], ["Qualidade", "Marcas e linhas selecionadas para uso profissional."], ["Atendimento direto", "Orçamento rápido pelo WhatsApp."], ["Para o setor", "Marceneiros, fábricas, lojas e profissionais."]].map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-black/10 p-6"><div className="mb-3 h-1 w-10 rounded bg-ato-700" /><h3 className="font-display text-2xl font-bold uppercase text-graphite">{t}</h3><p className="mt-1 text-black/60">{d}</p></div>
          ))}
        </div>
      </section>

      <section id="contato" className="bg-ato-900 py-20 text-white">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-4xl font-bold uppercase sm:text-6xl">Solicite seu orçamento</h2>
            <p className="mt-4 max-w-md text-white/70">Envie a lista de itens ou o código dos produtos e nossa equipe retorna com valores e prazos.</p>
            <a href={wa("Olá! Gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer" className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 font-semibold text-ato-900 hover:bg-ato-200"><WaIcon /> Falar no WhatsApp</a>
          </div>
          <dl className="grid gap-4 self-end text-sm sm:grid-cols-2">
            {[["WhatsApp", "(00) 00000-0000"], ["E-mail", "contato@ato.com.br"], ["Endereço", "A definir"], ["Horário", "Seg a Sex, 8h às 18h"]].map(([k, v]) => (
              <div key={k} className="rounded-xl border border-white/15 p-4"><dt className="text-white/50">{k}</dt><dd className="mt-1 text-base font-medium">{v}</dd></div>
            ))}
          </dl>
        </div>
      </section>
    </>
  );
}

function Catalog({ route, open }: { route: Extract<Route, { page: "catalog" }>; open: (p: Product) => void }) {
  const [q, setQ] = useState(route.q || "");
  const [cat, setCat] = useState(route.cat || "");
  const [material, setMaterial] = useState("");
  const [onlyFeatured, setOnlyFeatured] = useState(false);
  const [sort, setSort] = useState("rel");
  const [filtersOpen, setFiltersOpen] = useState(false);
  useEffect(() => { setCat(route.cat || ""); setQ(route.q || ""); }, [route.cat, route.q]);

  const materials = useMemo(() => [...new Set(products.map((p) => p.material))].sort(), []);
  const list = useMemo(() => {
    const n = q.trim().toLowerCase();
    let r = products.filter((p) =>
      (!cat || p.cat === cat) && (!material || p.material === material) && (!onlyFeatured || p.featured) &&
      (!n || [p.name, p.code, p.material, p.finish, ...p.specs.flat()].join(" ").toLowerCase().includes(n)));
    if (sort === "az") r = [...r].sort((a, b) => a.name.localeCompare(b.name));
    return r;
  }, [q, cat, material, onlyFeatured, sort]);
  const current = categories.find((c) => c.id === cat);
  const reset = () => { setQ(""); setCat(""); setMaterial(""); setOnlyFeatured(false); };

  const sidebar = (
    <div className="space-y-8">
      <div>
        <h3 className="font-display text-lg font-bold uppercase text-graphite">Categorias</h3>
        <ul className="mt-3 space-y-1 text-sm">
          <li><button onClick={() => setCat("")} className={`w-full rounded-lg px-3 py-2 text-left ${!cat ? "bg-ato-700 text-white" : "hover:bg-ato-50"}`}>Todas as categorias</button></li>
          {categories.map((c) => (
            <li key={c.id}><button onClick={() => { setCat(c.id); setFiltersOpen(false); }} className={`flex w-full justify-between gap-2 rounded-lg px-3 py-2 text-left ${cat === c.id ? "bg-ato-700 text-white" : "hover:bg-ato-50"}`}><span>{c.short}</span></button></li>
          ))}
        </ul>
      </div>
      <div>
        <h3 className="font-display text-lg font-bold uppercase text-graphite">Material</h3>
        <select value={material} onChange={(e) => setMaterial(e.target.value)} className="mt-3 w-full rounded-lg border border-black/15 bg-white px-3 py-2.5 text-sm">
          <option value="">Todos</option>
          {materials.map((m) => <option key={m}>{m}</option>)}
        </select>
        <label className="mt-4 flex items-center gap-2 text-sm"><input type="checkbox" checked={onlyFeatured} onChange={(e) => setOnlyFeatured(e.target.checked)} className="h-4 w-4 accent-[#2f7a4a]" /> Apenas destaques</label>
      </div>
      <button onClick={reset} className="text-sm font-semibold text-ato-700 hover:underline">Limpar filtros</button>
    </div>
  );

  return (
    <div>
      <div className="bg-ato-900 py-12 text-white">
        <div className="mx-auto max-w-7xl px-5">
          <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-ato-200">Catálogo digital</p>
          <h1 className="font-display text-4xl font-bold uppercase sm:text-6xl">{current ? current.name : "Todos os produtos"}</h1>
          <p className="mt-2 max-w-2xl text-white/70">{current ? current.desc : "Pesquise por nome, código, material ou medida."} Exibindo uma amostra do catálogo de 3.420 itens; solicite a lista completa pelo WhatsApp.</p>
          <div className="mt-6 flex max-w-2xl items-center gap-3 rounded-full bg-white px-5 py-1.5 text-graphite">
            <svg width="20" height="20" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.500-3.500" /></svg>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar dobradiça, corrediça, código..." className="w-full bg-transparent py-3 outline-none" />
            {q && <button onClick={() => setQ("")} className="text-sm text-black/40">Limpar</button>}
          </div>
        </div>
      </div>
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-10 lg:grid-cols-[260px_1fr]">
        <aside className="hidden lg:block">{sidebar}</aside>
        <div>
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-black/55"><b className="text-graphite">{list.length}</b> produto(s) encontrado(s)</p>
            <div className="flex items-center gap-3">
              <button onClick={() => setFiltersOpen(true)} className="rounded-full border border-black/15 px-4 py-2 text-sm font-semibold lg:hidden">Filtros</button>
              <select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-full border border-black/15 bg-white px-4 py-2 text-sm">
                <option value="rel">Relevância</option><option value="az">Nome (A–Z)</option>
              </select>
            </div>
          </div>
          {list.length ? (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{list.map((p) => <Card key={p.id} p={p} onOpen={open} />)}</div>
          ) : (
            <div className="rounded-2xl border border-dashed border-black/20 p-12 text-center">
              <p className="text-lg font-semibold text-graphite">Nenhum produto encontrado</p>
              <p className="mt-1 text-black/55">Não achou o que procura? Nosso catálogo tem mais de 3.400 itens.</p>
              <a href={wa(`Olá! Procuro por: ${q || "um item"}. Podem me ajudar?`)} target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-full bg-ato-700 px-6 py-3 font-semibold text-white"><WaIcon /> Consultar no WhatsApp</a>
            </div>
          )}
        </div>
      </div>
      {filtersOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 lg:hidden" onClick={() => setFiltersOpen(false)}>
          <div onClick={(e) => e.stopPropagation()} className="ml-auto h-full w-80 max-w-[90%] overflow-auto bg-white p-6">
            <button onClick={() => setFiltersOpen(false)} className="mb-4 text-sm font-semibold text-ato-700">Fechar</button>
            {sidebar}
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [route, setRoute] = useState<Route>(parseHash());
  const [sel, setSel] = useState<Product | null>(null);
  useEffect(() => {
    const f = () => { setRoute(parseHash()); if (!location.hash.startsWith("#/#")) window.scrollTo({ top: 0 }); };
    addEventListener("hashchange", f);
    return () => removeEventListener("hashchange", f);
  }, []);
  return (
    <div className="min-h-screen">
      <Header route={route} />
      <main>{route.page === "home" ? <Home open={setSel} /> : <Catalog route={route} open={setSel} />}</main>
      <footer className="border-t border-black/10 bg-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-8 text-sm text-black/55">
          <img src="/logo.jpg" alt="ATO" className="h-14 w-14 object-contain" />
          <p>© {new Date().getFullYear()} ATO — Acessórios para Móveis. Todos os direitos reservados.</p>
          <a href={wa("Olá!")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 font-semibold text-ato-700"><WaIcon /> WhatsApp</a>
        </div>
      </footer>
      <a href={wa("Olá! Gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="fixed bottom-5 right-5 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-[#25d366] text-white shadow-xl transition hover:scale-105"><svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.600 15.100L2 22l5-1.300A10 10 0 1 0 12 2Z" /></svg></a>
      <Modal p={sel} onClose={() => setSel(null)} />
    </div>
  );
}
